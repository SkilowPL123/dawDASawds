local meta = FindMetaTable('Player')
local metagive = meta.GiveAmmo
local metawep = meta.Give
-- local metastrip = meta.StripWeapon
hook.Add('OnEntityCreated', 'ArcCW_DefaultClipOVERRIDE', function(ent)
    if not ent.ArcCW then return end
    ent.Primary.DefaultClip = 0
end)

function meta:Give(class, noammo, direct)
    if not direct then
        metawep(self, class, noammo)
        return
    end

    -- print(direct, 'meta:Give', CurTime())
    self:GetInventory():Add(sup_inv.GetByName(class))
end

-- function meta:StripWeapon(wpn)
--     local inv = self:GetInventory()
--     local x, y = inv:Contains(wpn)
--     if not x or not y then continue end
--     local item = inv:GetItem(x, y)
--     if inv:GetEquipped(item.weptype) then inv:UnEquip(item.weptype, true) end
--     if inv:Contains(wpn) then 
--         timer.Simple(.05, function() 
--             inv:RemoveItem(x, y) end) 
--     end
--     metastrip(self, wpn)
-- end

function meta:GiveAmmo(amount, type, hidePopup, direct)
    if not direct then
        print(self, 'выдано', type, amount, 'direct =', direct)
        metagive(self, amount, type, hidePopup)
        return
    end

    -- print(direct, 'meta:GiveAmmo', CurTime())
    self:GetInventory():Add(sup_inv.GetByName(type), amount)
end