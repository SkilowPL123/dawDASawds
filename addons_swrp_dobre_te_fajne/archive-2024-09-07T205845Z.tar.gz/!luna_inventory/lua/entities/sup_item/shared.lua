ENT.Type = 'anim'
ENT.Base = 'base_gmodentity'
ENT.PrintName = 'Dropped item'
ENT.Author = 'arlekin4'
ENT.Spawnable = false
-- function ENT:SetupDataTables()
--     self:NetworkVar('Int', 0, 'amount')
--     self:NetworkVar('String', 0, 'WeaponClass')
-- end
function ENT:Draw()
    self:DrawModel()
end