util.AddNetworkString('inventory_update')
util.AddNetworkString('inventory_move')
util.AddNetworkString('inventory_action')
util.AddNetworkString('inventory_action2')
util.AddNetworkString('inventory_equip')
util.AddNetworkString('inventory_add_item')
local plymeta = FindMetaTable('Player')
local Inventory = {}
local sup_inv_cache = {}
Inventory.__index = Inventory
plymeta.pn = {}
function Inventory:New(ply, slots)
    if not slots then slots = 5 end
    local invv = {}
    invv.cont = {}
    invv.slots = slots
    for row = 1, slots do
        invv.cont[row] = {}
        for col = 1, slots do
            invv.cont[row][col] = false
        end
    end

    invv.equip = {
        main = false,
        secondary = false,
        heavy = false,
        var = false,
        ammo = false
    }

    ply:SetNW2Int('supinv.maxslots', slots)
    invv.owner = ply
    invv.weight = 0
    local v = setmetatable(invv, Inventory)
    sup_inv_cache[ply:SteamID()] = v
    return v
end

local function availableslot(inv, x, y)
    local cont = inv:GetContainer()
    return not cont[y][x]
end

function Inventory:GetContainer()
    return self.cont
end

function Inventory:GetItem(x, y)
    return self.cont[y][x]
end

function Inventory:GetSlots()
    return self.slots
end

function Inventory:Owner()
    return IsValid(self.owner) and self.owner or nil
end

function Inventory:RemoveItem(x, y)
    local item = self:GetItem(x, y)
    if isbool(item) then return false end
    self:AddWeight(-(item:GetWeight() * (item:IsWeapon() and 1 or item.amount)))
    self.cont[y][x] = false
    self:Owner():SyncInventory()
    return true
end

function Inventory:Contains(class)
    for y, row in ipairs(self.cont) do
        for x, slot in ipairs(row) do
            if not isbool(slot) and slot.class == class then return x, y end
        end
    end

    for _, item in pairs(self.equip) do
        if isbool(item) then continue end
        if item.class == class then return true end
    end
    return nil
end

function Inventory:GetByType(type, class)
    for y, row in ipairs(self.cont) do
        for x, slot in ipairs(row) do
            if not isbool(slot) and slot.weptype == type and slot.class == class then return x, y end
        end
    end
    return nil
end

function Inventory:GetWeight()
    return self.weight
end

function Inventory:AddWeight(val)
    self.weight = math.Clamp(self.weight + val, 0, 600)
end

function Inventory:Equip(slot, item)
    self.equip[slot] = item
    self:Owner():SyncInventory()
    if item:IsWeapon() then
        timer.Simple(.4, function()
            local w = self:Owner():GetWeapon(item:GetClass())
            if not IsValid(w) then return end
            w:SetClip1(item:GetClip() or 1)
            self:Owner():SelectWeapon(item:GetClass())
        end)
    end
    return true
end

function Inventory:GetEquipped(type)
    if not type then return end
    if not self.equip[type] then return end
    return self.equip[type]
end

function Inventory:UnEquip(slot, withrem)
    local ply = self:Owner()
    local eq = self:GetEquipped(slot)
    if withrem then
        self.equip[slot] = nil
        ply:StripWeapon(eq:GetClass())
        ply:SyncInventory()
        return
    end

    if type(eq) ~= 'table' then
        ErrorNoHalt('luna_inv/lua/sup_inv_core/sv/sv_inventory_main:Inventory:UnEquip Method: Expected slot to be a table, got', type(eq), '\n')
        return false
    end

    if eq and eq:IsWeapon() then
        if IsValid(ply:GetWeapon(eq:GetClass())) then self:Add(self.equip[slot]):SetClip(ply:GetWeapon(eq:GetClass()):Clip1()) end
        if ply:HasWeapon(eq:GetClass()) then ply:StripWeapon(eq:GetClass()) end
    elseif eq and eq:IsAmmo() then
        local amount = eq.amount
        local prevamount = ply:GetAmmoCount(eq:GetClass())
        self:AddWeight(self.equip[slot]:GetWeight() * prevamount)
        self:Add(self.equip[slot], prevamount):AddAmount(prevamount)
        ply:RemoveAmmo(prevamount - amount == 0 and amount or prevamount, eq:GetClass())
    end

    self.equip[slot] = nil
    ply:SyncInventory()
    return true
end

function Inventory:CheckPattern(pattern)
    local rows = #self.cont or 1
    local cols = #self.cont[1] or 1
    local pat_rows = #pattern
    local pat_cols = #pattern[1]
    for y = 1, rows - pat_rows + 1 do
        for x = 1, cols - pat_cols + 1 do
            local match = true
            for py = 1, pat_rows do
                for px = 1, pat_cols do
                    if pattern[py][px] and not self.cont[y + py - 1][x + px - 1] then
                        match = false
                    elseif not pattern[py][px] and self.cont[y + py - 1][x + px - 1] then
                        match = false
                    end
                end
            end

            if match then return true end
        end
    end
    return false
end

function Inventory:HasPattern(name)
    local pattern = patterns[name]
    if not pattern then return false end
    return self:CheckPattern(pattern)
end

function Inventory:Add(item, amount)
    local cont = self:GetContainer()
    if not item then return end
    amount = amount or 0
    for y = 1, #cont do
        for x = 1, #cont[y] do
            local slot = cont[y][x]
            if slot and slot:IsAmmo() and slot.class == item.class and item:IsAmmo() then
                slot.amount = (slot.amount or 1) + amount
                slot.hiddenamount = (slot.hiddenamount or 1) + amount
                self:AddWeight(slot:GetWeight() * slot.amount)
                self:Owner():SyncInventory()
                return slot
            end

            if not slot then
                cont[y][x] = item
                if item.amount and item:IsAmmo() then
                    self:AddWeight(item:GetWeight() * item.amount)
                elseif item:IsWeapon() then
                    self:AddWeight(item:GetWeight() * 1)
                end

                self:Owner():SyncInventory()
                return item
            end
        end
    end
    return false
end

local function domove(ply, oldX, oldY, newX, newY)
    local inv = ply:GetInventory()
    local item = inv:GetItem(oldX, oldY)
    if not item then
        ply:SyncInventory()
        return
    end

    if not availableslot(inv, newX, newY) then
        ply:SyncInventory()
        return
    end

    local cont = inv:GetContainer()
    cont[oldY][oldX] = false
    cont[newY][newX] = item
    ply:SyncInventory()
end

function plymeta:SyncInventory()
    net.Start('inventory_update')
    net.WriteTable(self:GetInventory().cont)
    net.WriteInt(self:GetInventory():GetWeight(), 10)
    net.WriteTable(self:GetInventory().equip)
    net.Send(self)
end

function plymeta:GetInventory()
    if self:HasInventory() then return sup_inv_cache[self:SteamID()] end
    return self:InitInventory()
end

function plymeta:HasInventory()
    return sup_inv_cache[self:SteamID()] ~= nil
end

function plymeta:InitInventory(slots)
    return Inventory:New(self, slots)
end

net.Receive('inventory_move', function(_, ply)
    local itemid = net.ReadString()
    local oldX = net.ReadUInt(6)
    local oldY = net.ReadUInt(6)
    local newX = net.ReadUInt(6)
    local newY = net.ReadUInt(6)
    domove(ply, oldX, oldY, newX, newY)
end)

hook.Add('PlayerUse', 'supreme.pickup', function(ply, ent)
    if ply:KeyDown(IN_WALK) and sup_inv.ValidItem(ent:GetClass()) then
        ply:GetInventory():Add(sup_inv.Contains(ent:GetClass()))
        ent:Remove()
    end
end)

hook.Add('PlayerCanPickupWeapon', 'supreme.nopickup', function(ply, wep) return ply.pn[wep] end)
hook.Add('PlayerInitialSpawn', 'supreme.initinv', function(ply) ply:InitInventory() end)
net.Receive('inventory_action2', function(_, ply)
    local ac = net.ReadString()
    local typo = net.ReadString()
    local inv = ply:GetInventory()
    if ac == 'unequip' then inv:UnEquip(typo) end
end)

net.Receive('inventory_action', function(_, ply)
    local ac = net.ReadString()
    local x = net.ReadInt(6)
    local y = net.ReadInt(6)
    local typ = net.ReadString()
    local inv = ply:GetInventory()
    local item = inv:GetItem(x, y)
    if typ == 'trashbin' then
        inv:RemoveItem(x, y)
        return
    end

    if ac == 'use' and item:IsWeapon() then ac = 'equip' end
    if ac == 'drop' and hook.Run('sup_inv.OnItemDropped', ply, x, y) then
        inv:RemoveItem(x, y)
        local ent = ents.Create(item:GetClass())
        ent:SetModel(item:GetModel())
        ent:SetPos(ply:GetBonePosition(ply:LookupBone('ValveBiped.Bip01_R_Hand')))
        ent:Activate()
        if item:IsWeapon() then ply.pn[ent] = true end
        ent:Spawn()
        ent:SetVelocity(ply:GetVelocity() * 150 + ply:GetAimVector() * 75)
        ply:DoAnimationEvent(ACT_GMOD_GESTURE_ITEM_GIVE)
        timer.Simple(1.2, function() if IsValid(ply) and item:IsWeapon() then ply.pn[ent] = nil end end)
    end

    if ac == 'use' then item:Use(ply, x, y) end
    if ac == 'equip' and not isbool(item) and not inv:GetEquipped(item:GetType()) then
        local slot = item:GetType()
        if item:Use(ply, x, y) then inv:Equip(slot, item) end
    end
end)

hook.Add('sup_inv.OnItemAdded', 'sup_inv.AddWeight', function(o, inv, item) inv:AddWeight(item:GetWeight() * item:GetAmount() or 1) end)
hook.Add('sup_inv.OnItemDropped', 'sup_inv.PerformDrop', function(ply, x, y) return true end)
net.Receive('inventory_equip', function(_, ply)
    local ac = net.ReadString()
    local _string = net.ReadString()
    local inv = ply:GetInventory()
    local x, y = inv:GetByType(ac, _string)
    local item = inv:GetItem(x, y)
    if not inv:GetEquipped(item:GetType()) and item:Use(ply, x, y) then inv:Equip(slot, item) end
end)

net.Receive('inventory_add_item', function(_, ply)
    -- if ply:GetUserGroup() ~= 'founder' or ply:GetUserGroupnot ply:IsSuperAdmin() then
    --     -- ply:ChatPrint('сосать')
    --     return
    -- end
    local v = net.ReadString()
    local item = sup_inv.GetByClass(v) or sup_inv.GetByName(v)
    if not item then return end
    local inv = ply:GetInventory()
    inv:Add(sup_inv.NewItem(item.class), item.type == 'ammo' and item.giveamount)
end)