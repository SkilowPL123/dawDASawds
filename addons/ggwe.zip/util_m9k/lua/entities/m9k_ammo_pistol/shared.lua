--leak by matveicher
--vk group - https://vk.com/codespill
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/7XaRzQSZ45
--ds - matveicher

ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= "Pistol Rounds"
ENT.Category	= "SUP • M9K"

ENT.Spawnable		= true
ENT.AdminOnly = false
ENT.DoNotDuplicate = true

if SERVER then

AddCSLuaFile("shared.lua")

function ENT:SpawnFunction(ply, tr)

	if (!tr.Hit) then return end
	
	local SpawnPos = tr.HitPos + tr.HitNormal * 16
	
	local ent = ents.Create("m9k_ammo_pistol")
	
	ent:SetPos(SpawnPos)
	ent:Spawn()
	ent:Activate()
	ent.Planted = false
	
	return ent
end


/*---------------------------------------------------------
   Name: Initialize
---------------------------------------------------------*/
function ENT:Initialize()

	local model = ("models/Items/BoxSRounds.mdl")
	
	self.Entity:SetModel(model)
	
	self.Entity:PhysicsInit(SOLID_VPHYSICS)
	self.Entity:SetMoveType(MOVETYPE_VPHYSICS)
	self.Entity:SetSolid(SOLID_VPHYSICS)
	self.Entity:DrawShadow(false)
	
	self.Entity:SetCollisionGroup(COLLISION_GROUP_WEAPON)
	
	local phys = self.Entity:GetPhysicsObject()
	
	if (phys:IsValid()) then
		phys:Wake()
	end

	self.Entity:SetUseType(SIMPLE_USE)
end


/*---------------------------------------------------------
   Name: PhysicsCollide
---------------------------------------------------------*/
function ENT:PhysicsCollide(data, physobj)
	
	// Play sound on bounce
	if (data.Speed > 80 and data.DeltaTime > 0.2) then
		self.Entity:EmitSound("Default.ImpactSoft")
	end
end

/*---------------------------------------------------------
   Name: OnTakeDamage
---------------------------------------------------------*/
function ENT:OnTakeDamage(dmginfo)

	if dmginfo:GetAttacker():GetClass() == "m9k_ammo_explosion" then return end
	
	self.Entity:TakePhysicsDamage(dmginfo)
	if GetConVar("M9KAmmoDetonation") == nil then return end
	if not (GetConVar("M9KAmmoDetonation"):GetBool()) then return end
	blaster = dmginfo:GetAttacker()
	pos = self.Entity:GetPos()+Vector(0,0,10)
	
	dice = math.random(1,5)

	if dmginfo:GetDamage() >75 or dice == 1 then
		self.Entity:Remove()
	
		local effectdata = EffectData()
		effectdata:SetOrigin(self.Entity:GetPos())
		util.Effect("ThumperDust", effectdata)
		util.Effect("Explosion", effectdata)
	
		timer.Simple(.01, function()
		
			for i=1, 100 do
			
			ouchies = {}
			ouchies.start = pos
			ouchies.endpos = pos + Vector(math.Rand(-1,1), math.Rand(-1,1), math.Rand(0,1)) * 64000
			ouchies = util.TraceLine(ouchies)
			
			if ouchies.Hit and not ouchies.HitSky then 
				util.Decal("Impact.Concrete", ouchies.HitPos + ouchies.HitNormal, ouchies.HitPos - ouchies.HitNormal )//and ouchies.Entity then
				ouchies.Entity:TakeDamage(30 * math.Rand(.85,1.15), blaster, self.Entity)
			end
			end
		end)
	end	

end

/*---------------------------------------------------------
   Name: Use
---------------------------------------------------------*/
function ENT:Use(activator, caller)

	
	if (activator:IsPlayer()) and not self.Planted then
		activator:GiveAmmo(100, "pistol")
		self.Entity:Remove()
	end
end

end

if CLIENT then

/*---------------------------------------------------------
   Name: Initialize
---------------------------------------------------------*/
function ENT:Initialize()
end

/*---------------------------------------------------------
   Name: DrawPre
---------------------------------------------------------*/
function ENT:Draw()
	
	self.Entity:DrawModel()
	
	local ledcolor = Color(230, 45, 45, 255)

  	local TargetPos = self.Entity:GetPos() + (self.Entity:GetUp() * 11.6) + (self.Entity:GetRight() * 2) + (self.Entity:GetForward() * 1.5)

	local FixAngles = self.Entity:GetAngles()
	local FixRotation = Vector(90, 90, 90)
	
	FixAngles:RotateAroundAxis(FixAngles:Right(), FixRotation.x)
	FixAngles:RotateAroundAxis(FixAngles:Up(), FixRotation.y)
	FixAngles:RotateAroundAxis(FixAngles:Forward(), FixRotation.z)

	self.Text = "Pistol Rounds"
	
	cam.Start3D2D(TargetPos, FixAngles, .07)
		draw.SimpleText(self.Text, "DermaLarge", 31, -22, ledcolor, 1, 1)
	cam.End3D2D()
end

end

--leak by matveicher
--vk group - https://vk.com/codespill
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/7XaRzQSZ45
--ds - matveicher
